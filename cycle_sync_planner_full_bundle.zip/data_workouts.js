
export const WORKOUTS = {
  "menstrual":[
    {"name":"Gentle Yoga + Breathwork","duration":"25–35 min","focus":"Mobility, legs/hips, diaphragmatic breathing"},
    {"name":"Easy Walk","duration":"30–45 min","focus":"Nasal breathing, low HR (Zone 1)"},
    {"name":"Light Pilates Flow","duration":"20–30 min","focus":"Core stability, no max effort"}
  ],
  "follicular":[
    {"name":"Strength (Upper/Lower Split)","duration":"35–45 min","focus":"2–3 sets x 8–10 reps; RPE 6–7"},
    {"name":"Upright Bike (steady)","duration":"20–30 min","focus":"Zone 2, conversational pace"},
    {"name":"Mobility Finisher","duration":"10–15 min","focus":"Hips/shoulders, foam roll"}
  ],
  "ovulation":[
    {"name":"Moderate Intervals (Bike/Row)","duration":"18–24 min","focus":"5×2 min moderate / 2 min easy; sub‑max"},
    {"name":"Total-Body Strength","duration":"35–45 min","focus":"Supersets; RPE 7"},
    {"name":"Long Walk","duration":"40–60 min","focus":"Sunlight if possible"}
  ],
  "luteal":[
    {"name":"Low-Impact Strength","duration":"30–40 min","focus":"Higher reps, slower tempo; RPE 6"},
    {"name":"Pilates or Barre","duration":"25–35 min","focus":"Core + glutes; mindful pace"},
    {"name":"Yoga + Breath","duration":"20–30 min","focus":"Down-regulation, sleep support"}
  ]
};
export const PHASE_INFO = {
  "menstrual":"Iron-rich foods (salmon, spinach, eggs), anti-inflammatory spices, more rest. Gentle movement helps cramps and mood.",
  "follicular":"Rising estrogen—fresh produce, lean proteins, fiber; great for skill/strength building.",
  "ovulation":"Peak energy—antioxidants and light, colorful foods; keep intensity moderate, avoid long HR spikes.",
  "luteal":"Support with magnesium/B-vitamins, complex carbs, and calm evenings. Favor low-impact strength and sleep hygiene."
};
