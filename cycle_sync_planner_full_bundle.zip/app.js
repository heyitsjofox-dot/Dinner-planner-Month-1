/* Full app logic (calendar, week, daily modal, grocery, ads) */
import { MEAL_CATALOG } from './data_meals.js';
import { WORKOUTS, PHASE_INFO } from './data_workouts.js';
import { fetchWeeklyAds } from './ads_fetchers.js';

const state = { year: 2025, month: (new Date()).getMonth(), plan:{}, settings:{sex:'female',age:39,height:165,weight:70,goal:'lose',activity:'light',lastPeriod:null,cycleLen:28}, ads:{Aldi:[],Publix:[]} };
(function load(){ const s=localStorage.getItem('foxy-planner-state'); if(s){ try{Object.assign(state, JSON.parse(s));}catch{}} const now=new Date(); if(state.year!==2025) state.year=2025; state.month = now.getFullYear()===2025? now.getMonth():0; })();
const save=()=>localStorage.setItem('foxy-planner-state', JSON.stringify(state));
const pad=n=>String(n).padStart(2,'0'); const dateKey=(y,m,d)=>`${y}-${pad(m+1)}-${pad(d)}`; const firstDOM=(y,m)=>new Date(y,m,1).getDay(); const dim=(y,m)=>new Date(y,m+1,0).getDate();
const monthLabel=document.getElementById('monthLabel'); const grid=document.getElementById('calendarGrid'); const calView=document.getElementById('calendarView'); const weekView=document.getElementById('weekView'); const groView=document.getElementById('groceryView');
function getPhaseForDate(dt){ if(!state.settings.lastPeriod) return 'follicular'; const lp=new Date(state.settings.lastPeriod); const cyc=state.settings.cycleLen||28; const diff=Math.floor((dt-lp)/(86400000)); const day=(diff%cyc+cyc)%cyc; if(day<=4) return 'menstrual'; if(day<=13) return 'follicular'; if(day<=16) return 'ovulation'; return 'luteal'; }
function renderCalendar(){ monthLabel.textContent=new Date(state.year,state.month,1).toLocaleString('en-US',{month:'long',year:'numeric'}); grid.innerHTML=''; const fd=firstDOM(state.year,state.month); const days=dim(state.year,state.month);
  for(let i=0;i<fd;i++){ const b=document.createElement('div'); b.className='day-cell'; grid.appendChild(b); }
  for(let d=1; d<=days; d++){ const key=dateKey(state.year,state.month,d); const plan=state.plan[key]||{}; const cell=document.createElement('div'); cell.className='day-cell';
    const head=document.createElement('div'); head.className='day-head'; const dateEl=document.createElement('div'); dateEl.className='date'; dateEl.textContent=d;
    const phase=plan.phase||getPhaseForDate(new Date(state.year,state.month,d)); const badge=document.createElement('div'); badge.className='phase-badge'; badge.textContent=phase;
    head.appendChild(dateEl); head.appendChild(badge); cell.appendChild(head);
    const mini=document.createElement('div'); mini.className='meal-mini'; mini.innerHTML=`<div>🥣 ${plan.breakfast?.name||'—'}</div><div>🥗 ${plan.lunch?.name||'—'}</div><div>🍽️ ${plan.dinner?.name||'—'}</div>`; cell.appendChild(mini);
    const btn=document.createElement('button'); btn.textContent='Open'; btn.addEventListener('click',()=>openDayModal(new Date(state.year,state.month,d))); cell.appendChild(btn);
    grid.appendChild(cell);
  }
}
renderCalendar();
document.getElementById('prevMonth').onclick=()=>{ state.month=(state.month+11)%12; if(state.month===11) state.year--; renderCalendar(); save(); fillGroceryScope(); };
document.getElementById('nextMonth').onclick=()=>{ state.month=(state.month+1)%12; if(state.month===0) state.year++; renderCalendar(); save(); fillGroceryScope(); };
let currentWeek=0; const weekLabel=document.getElementById('weekLabel'); const weekDays=document.getElementById('weekDays');
const weekIndex=(y,m,d)=>Math.floor((firstDOM(y,m)+(d-1))/7);
function renderWeek(){ weekDays.innerHTML=''; const days=dim(state.year,state.month); const fd=firstDOM(state.year,state.month); const start=currentWeek*7 - fd + 1; weekLabel.textContent=`Week ${currentWeek+1}`;
  for(let i=0;i<7;i++){ const d=start+i; const card=document.createElement('div'); card.className='week-card'; if(d<1||d>days){ weekDays.appendChild(card); continue; }
    const key=dateKey(state.year,state.month,d); const plan=state.plan[key]||{}; const phase=plan.phase||getPhaseForDate(new Date(state.year,state.month,d));
    card.innerHTML=`<header><strong>${new Date(state.year,state.month,d).toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric'})}</strong><span class="phase-badge">${phase}</span></header>
    <div class="mini-list">🥣 ${plan.breakfast?.name||'—'}<br>🥗 ${plan.lunch?.name||'—'}<br>🍽️ ${plan.dinner?.name||'—'}</div><div style="margin-top:6px"><button data-d="${d}">Open</button></div>`;
    card.querySelector('button').onclick=()=>openDayModal(new Date(state.year,state.month,d)); weekDays.appendChild(card);
  }
}
document.getElementById('viewMonthBtn').onclick=()=>{ calView.classList.remove('hidden'); weekView.classList.add('hidden'); groView.classList.add('hidden'); };
document.getElementById('viewWeekBtn').onclick=()=>{ calView.classList.add('hidden'); weekView.classList.remove('hidden'); groView.classList.add('hidden'); renderWeek(); };
document.getElementById('viewGroceryBtn').onclick=()=>{ calView.classList.add('hidden'); weekView.classList.add('hidden'); groView.classList.remove('hidden'); buildGrocery(); };
document.getElementById('prevWeek').onclick=()=>{ currentWeek=Math.max(0,currentWeek-1); renderWeek(); };
document.getElementById('nextWeek').onclick=()=>{ currentWeek=currentWeek+1; renderWeek(); };

// Settings
const settingsModal=document.getElementById('settingsModal');
document.getElementById('settingsBtn').onclick=()=>{ settingsModal.showModal(); ['sex','age','height','weight','goal','activity','cycleLen'].forEach(id=>{ const el=document.getElementById(id); if(el) el.value=state.settings[id]??el.value; }); document.getElementById('lastPeriod').value=state.settings.lastPeriod||''; };
document.getElementById('saveSettings').onclick=(e)=>{ e.preventDefault(); const g=id=>document.getElementById(id).value; state.settings.sex=g('sex'); state.settings.age=+g('age'); state.settings.height=+g('height'); state.settings.weight=+g('weight'); state.settings.goal=g('goal'); state.settings.activity=g('activity'); state.settings.cycleLen=+g('cycleLen'); state.settings.lastPeriod=g('lastPeriod')||null; save(); settingsModal.close(); renderCalendar(); };

// Modal
const dayModal=document.getElementById('dayModal'); const modalDate=document.getElementById('modalDate'); const modalPhase=document.getElementById('modalPhase'); const phaseDetails=document.getElementById('phaseDetails'); const recipeBody=document.getElementById('recipeBody'); const workoutPlan=document.getElementById('workoutPlan'); const breakfastSelect=document.getElementById('breakfastSelect'); const lunchSelect=document.getElementById('lunchSelect'); const dinnerSelect=document.getElementById('dinnerSelect'); let modalKey=null;
function fillMealSelect(sel, list, current){ sel.innerHTML=''; list.forEach(m=>{ const o=document.createElement('option'); o.value=m.name; o.textContent=m.name; if(m.name===current) o.selected=true; sel.appendChild(o); }); }
function renderRecipe(meal){ if(!meal){ recipeBody.textContent=''; return; } const lis=meal.ingredients.map(i=>`<li>${i.item} — <strong>${i.qty}</strong> ${i.unit}</li>`).join(''); recipeBody.innerHTML=`<div class="recipe"><p><em>Approx. ${meal.kcal} kcal</em></p><ul>${lis}</ul><p>${meal.steps}</p></div>`; }
function renderWorkout(phase){ const options=WORKOUTS[phase]||WORKOUTS.follicular; workoutPlan.innerHTML=options.map(o=>`<div>• <strong>${o.name}</strong> — ${o.duration} <em>(${o.focus})</em></div>`).join(''); modalPhase.textContent=phase; phaseDetails.textContent=PHASE_INFO[phase]||''; }
function getMealByName(name){ for(const t of ['breakfast','lunch','dinner']){ const m=MEAL_CATALOG[t].find(x=>x.name===name); if(m) return m; } return null; }
function openDayModal(dt){ modalKey=`${dt.getFullYear()}-${String(dt.getMonth()+1).padStart(2,'0')}-${String(dt.getDate()).padStart(2,'0')}`; const plan=state.plan[modalKey]||{phase:getPhaseForDate(dt)}; modalDate.textContent=dt.toLocaleDateString(undefined,{weekday:'long',month:'long',day:'numeric',year:'numeric'}); renderWorkout(plan.phase);
  fillMealSelect(breakfastSelect, MEAL_CATALOG.breakfast, plan.breakfast?.name); fillMealSelect(lunchSelect, MEAL_CATALOG.lunch, plan.lunch?.name); fillMealSelect(dinnerSelect, MEAL_CATALOG.dinner, plan.dinner?.name); renderRecipe(plan.dinner||plan.lunch||plan.breakfast); dayModal.showModal();
  [breakfastSelect,lunchSelect,dinnerSelect].forEach((sel,idx)=>sel.onchange=()=>{ const m=getMealByName(sel.value); if(idx===2) renderRecipe(m); });
}
document.getElementById('closeModal').onclick=()=>dayModal.close();
document.getElementById('saveDay').onclick=(e)=>{ e.preventDefault(); const phase=modalPhase.textContent; const plan={ phase, breakfast:getMealByName(breakfastSelect.value), lunch:getMealByName(lunchSelect.value), dinner:getMealByName(dinnerSelect.value) }; state.plan[modalKey]=plan; save(); dayModal.close(); renderCalendar(); };
document.getElementById('deleteDay').onclick=()=>{ delete state.plan[modalKey]; save(); dayModal.close(); renderCalendar(); };
document.querySelectorAll('.cycle-buttons .chip').forEach(btn=>btn.onclick=()=>renderWorkout(btn.dataset.phase));
document.getElementById('favDay').onclick=()=>{ const fav=JSON.parse(localStorage.getItem('foxy-favorites')||'{}'); fav[modalKey]=true; localStorage.setItem('foxy-favorites', JSON.stringify(fav)); alert('Saved to Favorites.'); };
const favMeal=name=>{ const fav=JSON.parse(localStorage.getItem('foxy-meal-favorites')||'[]'); if(!fav.includes(name)) fav.push(name); localStorage.setItem('foxy-meal-favorites', JSON.stringify(fav)); alert('Meal favorited: '+name); };
document.getElementById('favBreakfast').onclick=()=>favMeal(breakfastSelect.value); document.getElementById('favLunch').onclick=()=>favMeal(lunchSelect.value); document.getElementById('favDinner').onclick=()=>favMeal(dinnerSelect.value);
document.getElementById('addCustomMeal').onclick=()=>{ const type=prompt('Add to which list? (breakfast/lunch/dinner)','dinner'); const name=prompt('Meal name? (≤5 ingredients)','Custom Dish'); if(!type||!name) return; const recipe=prompt('Quick steps?','Build and season to taste.'); const m={name,ingredients:[],steps:recipe||'',kcal:400,phase:'any'}; MEAL_CATALOG[type].push(m); if(type==='breakfast') fillMealSelect(breakfastSelect,MEAL_CATALOG.breakfast,name); if(type==='lunch') fillMealSelect(lunchSelect,MEAL_CATALOG.lunch,name); if(type==='dinner') fillMealSelect(dinnerSelect,MEAL_CATALOG.dinner,name); };

// Grocery
const groceryScope=document.getElementById('groceryScope'); const groceryRows=document.getElementById('groceryRows'); const totalAldi=document.getElementById('totalAldi'); const totalPublix=document.getElementById('totalPublix');
function fillGroceryScope(){ groceryScope.innerHTML='<option value="month">Master (All Weeks)</option>'; const days=dim(state.year,state.month); const fd=firstDOM(state.year,state.month); const weeks=Math.ceil((fd+days)/7); for(let i=0;i<weeks;i++){ const opt=document.createElement('option'); opt.value=`week-${i+1}`; opt.textContent=`Week ${i+1}`; groceryScope.appendChild(opt);} }
fillGroceryScope();
function collectIngredientsForRange(startDay,endDay){ const agg=new Map(); for(let d=startDay; d<=endDay; d++){ const key=dateKey(state.year,state.month,d); const plan=state.plan[key]; if(!plan) continue; for(const meal of [plan.breakfast,plan.lunch,plan.dinner]){ if(!meal) continue; for(const ing of meal.ingredients){ const name=(ing.item||'').toLowerCase(); const k=name+'|'+(ing.unit||''); const cur=agg.get(k)||{item:ing.item,qty:0,unit:ing.unit||''}; cur.qty += Number(ing.qty)||0; agg.set(k,cur);} } } return Array.from(agg.values()); }
function buildGrocery(){ const days=dim(state.year,state.month); const fd=firstDOM(state.year,state.month); const scope=groceryScope.value; let items=[]; if(scope==='month'){ items=collectIngredientsForRange(1,days); } else { const wi=parseInt(scope.split('-')[1])-1; const start=wi*7 - fd + 1; const end=Math.min(start+6, days); items=collectIngredientsForRange(Math.max(1,start), Math.max(1,start)<=0?0:end); } renderGroceryRows(items); updateTotals(); }
function guessPrice(store, name){ const ads=state.ads && state.ads[store]? state.ads[store]:[]; const n=(name||'').toLowerCase(); for(const ad of ads){ if(n.includes(ad.item.toLowerCase())) return ad.price; } return 0; }
function renderGroceryRows(items){ groceryRows.innerHTML=''; items.sort((a,b)=>a.item.localeCompare(b.item)); for(const it of items){ const row=document.createElement('div'); row.className='g-row'; row.innerHTML=`
  <div class="cell"><input type="text" value="${it.item}" class="g-name"></div>
  <div class="cell small"><input type="number" min="0" step="0.01" value="${(it.qty||0).toFixed(2)}" class="g-qty"></div>
  <div class="cell small"><input type="text" value="${it.unit||''}" class="g-unit"></div>
  <div class="cell small"><input type="number" min="0" step="0.01" value="${guessPrice('Aldi',it.item)}" class="g-aldi"></div>
  <div class="cell small"><input type="number" min="0" step="0.01" value="${guessPrice('Publix',it.item)}" class="g-publix"></div>
  <div class="cell small"><input type="checkbox" class="g-fav"></div>`; groceryRows.appendChild(row); row.querySelector('.g-aldi').oninput=updateTotals; row.querySelector('.g-publix').oninput=updateTotals; } }
function updateTotals(){ let a=0,p=0; document.querySelectorAll('.g-row').forEach(r=>{ a+=parseFloat(r.querySelector('.g-aldi').value||0); p+=parseFloat(r.querySelector('.g-publix').value||0); }); totalAldi.textContent=a.toFixed(2); totalPublix.textContent=p.toFixed(2); }
document.getElementById('addGroceryItem').onclick=()=>{ const item=prompt('Item name?'); if(!item) return; const row=document.createElement('div'); row.className='g-row'; row.innerHTML=`
  <div class="cell"><input type="text" value="${item}" class="g-name"></div>
  <div class="cell small"><input type="number" min="0" step="0.01" value="1" class="g-qty"></div>
  <div class="cell small"><input type="text" value="ea" class="g-unit"></div>
  <div class="cell small"><input type="number" min="0" step="0.01" value="0" class="g-aldi"></div>
  <div class="cell small"><input type="number" min="0" step="0.01" value="0" class="g-publix"></div>
  <div class="cell small"><input type="checkbox" class="g-fav"></div>`; groceryRows.appendChild(row); updateTotals(); };
document.getElementById('saveGrocery').onclick=()=>{ const rows=[]; document.querySelectorAll('.g-row').forEach(r=>rows.push({ item:r.querySelector('.g-name').value, qty:parseFloat(r.querySelector('.g-qty').value||0), unit:r.querySelector('.g-unit').value, aldi:parseFloat(r.querySelector('.g-aldi').value||0), publix:parseFloat(r.querySelector('.g-publix').value||0), fav:r.querySelector('.g-fav').checked })); const scope=groceryScope.value; localStorage.setItem('foxy-grocery-'+scope, JSON.stringify(rows)); alert('Grocery list saved.'); };
document.getElementById('clearChecked').onclick=()=>{ document.querySelectorAll('.g-row .g-fav:checked').forEach(cb=>cb.closest('.g-row').remove()); updateTotals(); };
groceryScope.onchange=buildGrocery;
document.getElementById('refreshAdsBtn').onclick=async()=>{ state.ads = await fetchWeeklyAds(); save(); buildGrocery(); alert('Weekly ads refreshed (sample data).'); };
renderCalendar();
