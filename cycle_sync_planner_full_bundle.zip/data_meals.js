export const MEAL_CATALOG = {
  "breakfast": [
    {
      "name": "Egg + Spinach Scramble",
      "ingredients": [
        {
          "item": "eggs",
          "qty": 2,
          "unit": "ea"
        },
        {
          "item": "spinach",
          "qty": 1,
          "unit": "cup"
        },
        {
          "item": "olive oil",
          "qty": 1,
          "unit": "tsp"
        },
        {
          "item": "feta",
          "qty": 1,
          "unit": "oz"
        },
        {
          "item": "salt & pepper",
          "qty": 1,
          "unit": "pinch"
        }
      ],
      "steps": "Scramble eggs with spinach; finish with feta.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Avocado Toast + Egg",
      "ingredients": [
        {
          "item": "sourdough bread",
          "qty": 1,
          "unit": "slice"
        },
        {
          "item": "avocado",
          "qty": 0.5,
          "unit": "ea"
        },
        {
          "item": "egg",
          "qty": 1,
          "unit": "ea"
        },
        {
          "item": "lemon",
          "qty": 1,
          "unit": "wedge"
        },
        {
          "item": "salt",
          "qty": 1,
          "unit": "pinch"
        }
      ],
      "steps": "Toast, mash avo, top with egg.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Berry Protein Smoothie",
      "ingredients": [
        {
          "item": "frozen berries",
          "qty": 1,
          "unit": "cup"
        },
        {
          "item": "banana",
          "qty": 0.5,
          "unit": "ea"
        },
        {
          "item": "spinach",
          "qty": 1,
          "unit": "cup"
        },
        {
          "item": "protein powder",
          "qty": 1,
          "unit": "scoop"
        },
        {
          "item": "almond milk",
          "qty": 1,
          "unit": "cup"
        }
      ],
      "steps": "Blend.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Tomato Basil Egg Skillet",
      "ingredients": [
        {
          "item": "eggs",
          "qty": 2,
          "unit": "ea"
        },
        {
          "item": "cherry tomatoes",
          "qty": 0.75,
          "unit": "cup"
        },
        {
          "item": "basil",
          "qty": 6,
          "unit": "leaves"
        },
        {
          "item": "olive oil",
          "qty": 1,
          "unit": "tsp"
        },
        {
          "item": "parmesan",
          "qty": 1,
          "unit": "tbsp"
        }
      ],
      "steps": "Saut\u00e9 tomatoes; soft scramble; finish with basil + parm.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "PB Banana Rice Cakes",
      "ingredients": [
        {
          "item": "rice cake",
          "qty": 2,
          "unit": "ea"
        },
        {
          "item": "peanut butter",
          "qty": 1,
          "unit": "tbsp"
        },
        {
          "item": "banana",
          "qty": 0.5,
          "unit": "ea"
        },
        {
          "item": "chia seeds",
          "qty": 1,
          "unit": "tsp"
        },
        {
          "item": "honey",
          "qty": 1,
          "unit": "tsp"
        }
      ],
      "steps": "Assemble.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Smoked Salmon + Cucumber Plate",
      "ingredients": [
        {
          "item": "smoked salmon",
          "qty": 2,
          "unit": "oz"
        },
        {
          "item": "cucumber",
          "qty": 0.5,
          "unit": "ea"
        },
        {
          "item": "cream cheese",
          "qty": 1,
          "unit": "tbsp"
        },
        {
          "item": "lemon",
          "qty": 1,
          "unit": "wedge"
        },
        {
          "item": "capers",
          "qty": 1,
          "unit": "tsp"
        }
      ],
      "steps": "Assemble.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Protein Coffee Shake",
      "ingredients": [
        {
          "item": "cold brew",
          "qty": 1,
          "unit": "cup"
        },
        {
          "item": "protein powder",
          "qty": 1,
          "unit": "scoop"
        },
        {
          "item": "almond milk",
          "qty": 0.75,
          "unit": "cup"
        },
        {
          "item": "ice",
          "qty": 1,
          "unit": "cup"
        },
        {
          "item": "cinnamon",
          "qty": 1,
          "unit": "dash"
        }
      ],
      "steps": "Blend.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Apple Cheddar Roll-Up",
      "ingredients": [
        {
          "item": "low-carb wrap",
          "qty": 1,
          "unit": "ea"
        },
        {
          "item": "apple",
          "qty": 0.5,
          "unit": "ea"
        },
        {
          "item": "sharp cheddar",
          "qty": 1.5,
          "unit": "oz"
        },
        {
          "item": "spinach",
          "qty": 0.5,
          "unit": "cup"
        },
        {
          "item": "mustard",
          "qty": 1,
          "unit": "tsp"
        }
      ],
      "steps": "Roll; warm 1\u20132 min.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Blueberry Chia Parfait",
      "ingredients": [
        {
          "item": "greek yogurt",
          "qty": 0.75,
          "unit": "cup"
        },
        {
          "item": "blueberries",
          "qty": 0.75,
          "unit": "cup"
        },
        {
          "item": "chia seeds",
          "qty": 1,
          "unit": "tbsp"
        },
        {
          "item": "vanilla",
          "qty": 0.25,
          "unit": "tsp"
        },
        {
          "item": "honey",
          "qty": 1,
          "unit": "tsp"
        }
      ],
      "steps": "Stir; top with berries.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Egg & Potato Hash",
      "ingredients": [
        {
          "item": "baby potatoes",
          "qty": 6,
          "unit": "oz"
        },
        {
          "item": "eggs",
          "qty": 2,
          "unit": "ea"
        },
        {
          "item": "olive oil",
          "qty": 1,
          "unit": "tsp"
        },
        {
          "item": "onion",
          "qty": 0.25,
          "unit": "ea"
        },
        {
          "item": "paprika",
          "qty": 0.25,
          "unit": "tsp"
        }
      ],
      "steps": "Crisp potatoes; fry eggs on top.",
      "phase": "any",
      "kcal": 400
    }
  ],
  "lunch": [
    {
      "name": "Caprese Spinach Salad",
      "ingredients": [
        {
          "item": "spinach",
          "qty": 2,
          "unit": "cups"
        },
        {
          "item": "mozzarella",
          "qty": 2,
          "unit": "oz"
        },
        {
          "item": "tomato",
          "qty": 1,
          "unit": "ea"
        },
        {
          "item": "basil",
          "qty": 8,
          "unit": "leaves"
        },
        {
          "item": "balsamic",
          "qty": 1,
          "unit": "tbsp"
        }
      ],
      "steps": "Toss.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Tuna Wrap",
      "ingredients": [
        {
          "item": "tuna (canned)",
          "qty": 1,
          "unit": "can"
        },
        {
          "item": "low-carb wrap",
          "qty": 1,
          "unit": "ea"
        },
        {
          "item": "celery",
          "qty": 0.25,
          "unit": "cup"
        },
        {
          "item": "light mayo",
          "qty": 1,
          "unit": "tbsp"
        },
        {
          "item": "spinach",
          "qty": 1,
          "unit": "cup"
        }
      ],
      "steps": "Mix + wrap.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Shrimp Zoodles",
      "ingredients": [
        {
          "item": "shrimp",
          "qty": 4,
          "unit": "oz"
        },
        {
          "item": "zucchini noodles",
          "qty": 2,
          "unit": "cups"
        },
        {
          "item": "garlic",
          "qty": 1,
          "unit": "clove"
        },
        {
          "item": "olive oil",
          "qty": 1,
          "unit": "tsp"
        },
        {
          "item": "lemon",
          "qty": 1,
          "unit": "wedge"
        }
      ],
      "steps": "Saut\u00e9; toss.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Egg Fried Rice (lite)",
      "ingredients": [
        {
          "item": "cooked rice",
          "qty": 1,
          "unit": "cup"
        },
        {
          "item": "egg",
          "qty": 1,
          "unit": "ea"
        },
        {
          "item": "peas & carrots",
          "qty": 0.5,
          "unit": "cup"
        },
        {
          "item": "soy sauce",
          "qty": 1,
          "unit": "tsp"
        },
        {
          "item": "sesame oil",
          "qty": 0.5,
          "unit": "tsp"
        }
      ],
      "steps": "Stir-fry.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Tomato Basil Pasta",
      "ingredients": [
        {
          "item": "pasta",
          "qty": 2,
          "unit": "oz"
        },
        {
          "item": "olive oil",
          "qty": 1,
          "unit": "tbsp"
        },
        {
          "item": "garlic",
          "qty": 1,
          "unit": "clove"
        },
        {
          "item": "tomato",
          "qty": 1,
          "unit": "ea"
        },
        {
          "item": "parmesan",
          "qty": 1,
          "unit": "tbsp"
        }
      ],
      "steps": "Cook pasta; saut\u00e9; toss.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Mozzarella Pesto Sandwich",
      "ingredients": [
        {
          "item": "sourdough",
          "qty": 2,
          "unit": "slices"
        },
        {
          "item": "mozzarella",
          "qty": 2,
          "unit": "oz"
        },
        {
          "item": "pesto",
          "qty": 1,
          "unit": "tbsp"
        },
        {
          "item": "tomato",
          "qty": 0.5,
          "unit": "ea"
        },
        {
          "item": "spinach",
          "qty": 0.5,
          "unit": "cup"
        }
      ],
      "steps": "Toast in pan.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Salmon Spinach Salad",
      "ingredients": [
        {
          "item": "cooked salmon",
          "qty": 4,
          "unit": "oz"
        },
        {
          "item": "spinach",
          "qty": 2,
          "unit": "cups"
        },
        {
          "item": "cucumber",
          "qty": 0.5,
          "unit": "ea"
        },
        {
          "item": "olive oil",
          "qty": 1,
          "unit": "tbsp"
        },
        {
          "item": "lemon",
          "qty": 1,
          "unit": "wedge"
        }
      ],
      "steps": "Flake; dress.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Beef & Pepper Lettuce Cups",
      "ingredients": [
        {
          "item": "ground beef (lean)",
          "qty": 4,
          "unit": "oz"
        },
        {
          "item": "bell pepper",
          "qty": 0.5,
          "unit": "ea"
        },
        {
          "item": "butter lettuce",
          "qty": 6,
          "unit": "leaves"
        },
        {
          "item": "soy sauce",
          "qty": 1,
          "unit": "tsp"
        },
        {
          "item": "sesame oil",
          "qty": 0.5,
          "unit": "tsp"
        }
      ],
      "steps": "Brown; fill.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Shrimp Tacos",
      "ingredients": [
        {
          "item": "shrimp",
          "qty": 4,
          "unit": "oz"
        },
        {
          "item": "corn tortillas",
          "qty": 2,
          "unit": "ea"
        },
        {
          "item": "cabbage slaw",
          "qty": 0.75,
          "unit": "cup"
        },
        {
          "item": "lime",
          "qty": 1,
          "unit": "wedge"
        },
        {
          "item": "crema",
          "qty": 1,
          "unit": "tbsp"
        }
      ],
      "steps": "Saut\u00e9 shrimp; assemble.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Egg, Rice & Spinach Bowl",
      "ingredients": [
        {
          "item": "cooked rice",
          "qty": 0.75,
          "unit": "cup"
        },
        {
          "item": "eggs",
          "qty": 2,
          "unit": "ea"
        },
        {
          "item": "spinach",
          "qty": 1,
          "unit": "cup"
        },
        {
          "item": "soy sauce",
          "qty": 1,
          "unit": "tsp"
        },
        {
          "item": "sesame oil",
          "qty": 0.5,
          "unit": "tsp"
        }
      ],
      "steps": "Saut\u00e9 spinach; scramble; combine.",
      "phase": "any",
      "kcal": 400
    }
  ],
  "dinner": [
    {
      "name": "Sheet-Pan Salmon & Asparagus",
      "ingredients": [
        {
          "item": "salmon",
          "qty": 5,
          "unit": "oz"
        },
        {
          "item": "asparagus",
          "qty": 6,
          "unit": "oz"
        },
        {
          "item": "olive oil",
          "qty": 1,
          "unit": "tbsp"
        },
        {
          "item": "lemon",
          "qty": 1,
          "unit": "wedge"
        },
        {
          "item": "garlic",
          "qty": 1,
          "unit": "clove"
        }
      ],
      "steps": "Roast 425\u00b0F 12\u201315 min.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Shrimp Zucchini Skillet",
      "ingredients": [
        {
          "item": "shrimp",
          "qty": 5,
          "unit": "oz"
        },
        {
          "item": "zucchini",
          "qty": 1,
          "unit": "ea"
        },
        {
          "item": "garlic",
          "qty": 2,
          "unit": "cloves"
        },
        {
          "item": "olive oil",
          "qty": 1,
          "unit": "tbsp"
        },
        {
          "item": "lemon",
          "qty": 1,
          "unit": "wedge"
        }
      ],
      "steps": "Saut\u00e9 6\u20137 min.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Beef & Peppers Stir-Fry",
      "ingredients": [
        {
          "item": "lean beef strips",
          "qty": 5,
          "unit": "oz"
        },
        {
          "item": "bell pepper",
          "qty": 1,
          "unit": "ea"
        },
        {
          "item": "onion",
          "qty": 0.5,
          "unit": "ea"
        },
        {
          "item": "soy sauce",
          "qty": 1,
          "unit": "tbsp"
        },
        {
          "item": "sesame oil",
          "qty": 1,
          "unit": "tsp"
        }
      ],
      "steps": "High heat stir-fry.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Garlic Butter Cod + Broccoli",
      "ingredients": [
        {
          "item": "cod",
          "qty": 5,
          "unit": "oz"
        },
        {
          "item": "broccoli",
          "qty": 8,
          "unit": "oz"
        },
        {
          "item": "butter",
          "qty": 1,
          "unit": "tbsp"
        },
        {
          "item": "garlic",
          "qty": 2,
          "unit": "cloves"
        },
        {
          "item": "lemon",
          "qty": 1,
          "unit": "wedge"
        }
      ],
      "steps": "Roast broccoli; sear cod.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Caprese Pasta",
      "ingredients": [
        {
          "item": "pasta",
          "qty": 3,
          "unit": "oz"
        },
        {
          "item": "tomato",
          "qty": 1,
          "unit": "ea"
        },
        {
          "item": "mozzarella",
          "qty": 2,
          "unit": "oz"
        },
        {
          "item": "basil",
          "qty": 8,
          "unit": "leaves"
        },
        {
          "item": "olive oil",
          "qty": 1,
          "unit": "tbsp"
        }
      ],
      "steps": "Cook & toss.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Beef Lettuce Taco Night",
      "ingredients": [
        {
          "item": "lean ground beef",
          "qty": 5,
          "unit": "oz"
        },
        {
          "item": "butter lettuce",
          "qty": 8,
          "unit": "leaves"
        },
        {
          "item": "tomato",
          "qty": 1,
          "unit": "ea"
        },
        {
          "item": "cheese",
          "qty": 1,
          "unit": "oz"
        },
        {
          "item": "salsa",
          "qty": 2,
          "unit": "tbsp"
        }
      ],
      "steps": "Brown beef; assemble.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Shrimp Lemon Pasta",
      "ingredients": [
        {
          "item": "pasta",
          "qty": 3,
          "unit": "oz"
        },
        {
          "item": "shrimp",
          "qty": 5,
          "unit": "oz"
        },
        {
          "item": "olive oil",
          "qty": 1,
          "unit": "tbsp"
        },
        {
          "item": "garlic",
          "qty": 2,
          "unit": "cloves"
        },
        {
          "item": "lemon",
          "qty": 1,
          "unit": "wedge"
        }
      ],
      "steps": "Cook pasta; saut\u00e9; toss.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Seared Salmon + Spinach",
      "ingredients": [
        {
          "item": "salmon",
          "qty": 5,
          "unit": "oz"
        },
        {
          "item": "spinach",
          "qty": 3,
          "unit": "cups"
        },
        {
          "item": "olive oil",
          "qty": 1,
          "unit": "tbsp"
        },
        {
          "item": "garlic",
          "qty": 2,
          "unit": "cloves"
        },
        {
          "item": "lemon",
          "qty": 1,
          "unit": "wedge"
        }
      ],
      "steps": "Sear salmon; wilt spinach.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Tomato Basil Flatbread",
      "ingredients": [
        {
          "item": "flatbread",
          "qty": 1,
          "unit": "ea"
        },
        {
          "item": "tomato",
          "qty": 1,
          "unit": "ea"
        },
        {
          "item": "mozzarella",
          "qty": 2,
          "unit": "oz"
        },
        {
          "item": "basil",
          "qty": 8,
          "unit": "leaves"
        },
        {
          "item": "olive oil",
          "qty": 1,
          "unit": "tbsp"
        }
      ],
      "steps": "Bake 8\u201310 min 425\u00b0F.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Egg Fried Rice (Dinner)",
      "ingredients": [
        {
          "item": "cooked rice",
          "qty": 1,
          "unit": "cup"
        },
        {
          "item": "egg",
          "qty": 2,
          "unit": "ea"
        },
        {
          "item": "peas & carrots",
          "qty": 0.75,
          "unit": "cup"
        },
        {
          "item": "soy sauce",
          "qty": 1,
          "unit": "tbsp"
        },
        {
          "item": "sesame oil",
          "qty": 1,
          "unit": "tsp"
        }
      ],
      "steps": "Stir-fry.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Zucchini Beef Boats",
      "ingredients": [
        {
          "item": "zucchini",
          "qty": 2,
          "unit": "ea"
        },
        {
          "item": "lean ground beef",
          "qty": 5,
          "unit": "oz"
        },
        {
          "item": "tomato sauce",
          "qty": 0.75,
          "unit": "cup"
        },
        {
          "item": "mozzarella",
          "qty": 1,
          "unit": "oz"
        },
        {
          "item": "onion",
          "qty": 0.25,
          "unit": "ea"
        }
      ],
      "steps": "Fill & bake 20 min.",
      "phase": "any",
      "kcal": 400
    },
    {
      "name": "Spinach Feta Rice Bowl",
      "ingredients": [
        {
          "item": "cooked rice",
          "qty": 0.75,
          "unit": "cup"
        },
        {
          "item": "spinach",
          "qty": 2,
          "unit": "cups"
        },
        {
          "item": "feta",
          "qty": 1.5,
          "unit": "oz"
        },
        {
          "item": "olive oil",
          "qty": 1,
          "unit": "tbsp"
        },
        {
          "item": "lemon",
          "qty": 1,
          "unit": "wedge"
        }
      ],
      "steps": "Wilt spinach; toss with rice.",
      "phase": "any",
      "kcal": 400
    }
  ]
};