
export async function fetchWeeklyAds(){
  try{
    const res = await fetch('./sample_data/ads.json',{cache:'no-store'});
    if(!res.ok) throw new Error('Sample ads not found');
    return await res.json();
  }catch(err){
    console.warn('Using empty ad data:', err.message);
    return {Aldi:[], Publix:[]};
  }
}
